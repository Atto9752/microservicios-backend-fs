package com.example.admin.controller;

public class AdminControllerTest {
    
}

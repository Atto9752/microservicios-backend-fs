package com.example.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.admin.model.dto.admin;

public interface adminRepositorio extends JpaRepository<admin, Integer>{

}
